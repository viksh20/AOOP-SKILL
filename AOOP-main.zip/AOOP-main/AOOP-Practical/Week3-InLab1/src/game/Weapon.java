package game;

public interface Weapon {
	void use();
}
