package game;

public class SwordWeapon implements Weapon {
	public void use() {
        System.out.println("Sword weapon used!");
    }
}
