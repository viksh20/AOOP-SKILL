package game;

public interface Enemy {
	void attack();
}
