package PL;

public class Car implements Vehicle {
	public void requestRide() {
        System.out.println("Requesting a Car Ride!!!");
    }
}
