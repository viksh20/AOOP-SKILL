package PL;

public interface Vehicle {
	void requestRide();
}
