package factoryPattern;

public class Truck implements Vehicle {

    @Override
    public void drive() {
        System.out.println("I am driving a truck");
    }
}
