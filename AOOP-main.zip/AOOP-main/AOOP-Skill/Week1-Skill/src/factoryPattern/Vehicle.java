package factoryPattern;

public interface Vehicle {
    void drive();
}
