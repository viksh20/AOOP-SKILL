// File: Command.java
package com.ordermanagement;

public interface Command {
    void execute();
}
